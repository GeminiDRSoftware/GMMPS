#!/bin/sh
# 
# This script updates a C source file to contain the bitmaps in this dir.

tclsh bitmaps.tcl > ../generic/rtd_bitmaps.C
