#!/bin/sh
# 
# This script updates a C source file to contain the colormaps in this dir.

tclsh colormaps.tcl > ../generic/colormaps.C
